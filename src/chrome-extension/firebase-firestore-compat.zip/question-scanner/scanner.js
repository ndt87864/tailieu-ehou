// Question Scanner - Quét câu hỏi và đáp án từ web
// Chức năng: Quét câu hỏi và tìm đáp án theo pattern "Đáp án đúng là: ..."

(function() {
    'use strict';

    // Prevent multiple injections
    if (window.tailieuScannerLoaded) {
        return;
    }
    window.tailieuScannerLoaded = true;

    let scannedQuestions = [];
    let existingQuestions = [];
    let existingQuestionKeys = new Set();

    // Normalize text for comparison
    function normalizeText(text) {
        if (!text) return '';
        return text
            .toLowerCase()
            .trim()
            .replace(/\s+/g, ' ')
            .replace(/[^\w\sáàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđ]/gi, '');
    }

    // Small SVG icon helper: returns an element for common icons
    function svgIcon(name, size = 18) {
        const ns = 'http://www.w3.org/2000/svg';
        const svg = document.createElementNS(ns, 'svg');
        svg.setAttribute('width', String(size));
        svg.setAttribute('height', String(size));
        svg.setAttribute('viewBox', '0 0 24 24');
        svg.setAttribute('fill', 'currentColor');
        svg.style.verticalAlign = 'middle';
        svg.style.display = 'inline-block';

        const path = document.createElementNS(ns, 'path');

        switch (name) {
            case 'save':
                path.setAttribute('d', 'M17 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7l-4-4zM12 19a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm3-14l3 3h-3V5z');
                break;
            case 'edit':
                path.setAttribute('d', 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z');
                break;
            case 'search':
                path.setAttribute('d', 'M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zM10 14a4 4 0 1 1 0-8 4 4 0 0 1 0 8z');
                break;
            case 'copy':
                path.setAttribute('d', 'M16 1H4a2 2 0 0 0-2 2v12h2V3h12V1zM20 5H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h12v14z');
                break;
            case 'book':
                path.setAttribute('d', 'M18 2H6a2 2 0 0 0-2 2v15a1 1 0 0 0 1.447.894L12 17l6.553 2.894A1 1 0 0 0 20 19V4a2 2 0 0 0-2-2z');
                break;
            case 'merge':
                path.setAttribute('d', 'M10 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM6 7v6a6 6 0 0 0 6 6h4v-2h-4a4 4 0 0 1-4-4V7H6zM18 13v-2h-2v2h2z');
                break;
            case 'check':
                path.setAttribute('d', 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z');
                break;
            case 'close':
                path.setAttribute('d', 'M18.3 5.71L12 12l6.3 6.29-1.41 1.42L10.59 13.4 4.29 19.71 2.88 18.3 9.18 12 2.88 5.71 4.29 4.29 10.59 10.6 16.88 4.29z');
                break;
            default:
                path.setAttribute('d', '');
        }

        svg.appendChild(path);
        return svg;
    }

    // Check if question is invalid/noise
    function isInvalidQuestion(text) {
        if (!text || text.length < 10) return true;
        
        const trimmedText = text.trim();
        
        // Pattern: "Question 1 Trang này", "Question 2 Trang này", etc.
        if (/^Question\s+\d+\s+Trang\s+này$/i.test(trimmedText)) {
            return true;
        }
        
        // Pattern: "Mô tả câu hỏi" (exact match or starts with)
        if (/^Mô tả câu hỏi/i.test(trimmedText)) {
            return true;
        }
        
        // Pattern: Contains only "Mô tả câu hỏi"
        if (trimmedText.toLowerCase() === 'mô tả câu hỏi') {
            return true;
        }
        
        // Pattern: Just "Question N" or "Câu N"
        if (/^(Question|Câu)\s+\d+$/i.test(trimmedText)) {
            return true;
        }
        
        // Pattern: "Trang này" alone
        if (/^Trang\s+này$/i.test(trimmedText)) {
            return true;
        }
        
        // Pattern: Contains only "Question N Trang này" pattern repeatedly
        if (/^(Question\s+\d+\s+Trang\s+này\s*)+$/i.test(trimmedText)) {
            return true;
        }
        
        // Pattern: Contains "Mô tả câu hỏi" followed by Question N Trang này
        if (/Mô tả câu hỏi.*Question\s+\d+\s+Trang\s+này/i.test(trimmedText)) {
            return true;
        }
        
        return false;
    }

    // Clean question text - remove "Mô tả câu hỏi" prefix and everything from "Chọn một câu trả lời:" onwards
    function cleanQuestionText(text) {
        if (!text) return '';
        
        let cleaned = text.trim();
        
        // Remove "Mô tả câu hỏi" prefix with optional whitespace
        cleaned = cleaned.replace(/^Mô tả câu hỏi\s*/i, '');
        
        // Remove everything from "Chọn một câu trả lời:" onwards (and the phrase itself)
        cleaned = cleaned.replace(/\s*Chọn một câu trả lời:[\s\S]*/i, '');
        
        // Remove "Choose one answer:" and everything after
        cleaned = cleaned.replace(/\s*Choose one answer:[\s\S]*/i, '');
        
        // Remove "Select one:" and everything after
        cleaned = cleaned.replace(/\s*Select one:[\s\S]*/i, '');
        
        // Remove other common patterns that indicate start of answer section
        cleaned = cleaned.replace(/\s*(a|A)\.\s+/g, ' '); // Remove answer choices
        cleaned = cleaned.replace(/\s+(b|B)\.\s+/g, ' ');
        cleaned = cleaned.replace(/\s+(c|C)\.\s+/g, ' ');
        cleaned = cleaned.replace(/\s+(d|D)\.\s+/g, ' ');
        
        // Clean up extra whitespace
        cleaned = cleaned.replace(/\s+/g, ' ').trim();
        
        return cleaned;
    }

    // Extract core question (without answer choices)
    function extractCoreQuestion(questionText) {
        let core = cleanQuestionText(questionText);
        
        // Split by newline and get first meaningful line (actual question)
        const lines = core.split('\n');
        let firstLine = '';
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i]?.trim();
            if (!line) continue;
            
            // Skip if it looks like an answer choice (a. b. c. d.)
            if (line.match(/^[a-d]\.\s*/i)) continue;
            
            firstLine = line;
            break;
        }
        
        return firstLine || core;
    }

    // Check if two questions are duplicates (same core question)
    function isDuplicateQuestion(q1Text, q2Text) {
        const core1 = normalizeText(extractCoreQuestion(q1Text));
        const core2 = normalizeText(extractCoreQuestion(q2Text));
        
        return core1 === core2;
    }

    // Extract questions from page
    function extractQuestionsFromPage() {
        const questions = [];
        
        // Pattern 1: Tìm các thẻ chứa câu hỏi
        const questionElements = document.querySelectorAll('.qtext, .question-text, [class*="question"], .formulation');
        
        questionElements.forEach((element, index) => {
            try {
                // Skip any elements that are part of our extension UI (avoid scanning popup/DB list)
                if (!element) return;
                const elId = (element.id || '').toLowerCase();
                const elClass = (element.className || '').toLowerCase();
                if (elId.includes('tailieu') || elClass.includes('tailieu') || element.hasAttribute && element.hasAttribute('data-tailieu')) {
                    return;
                }

                const questionText = element.innerText?.trim();
                if (!questionText || questionText.length < 10) return;

                // DEBUG: log raw extracted question snippet (first 200 chars)
                try {
                    console.debug('[scanner] extracted raw question:', (questionText || '').slice(0, 200));
                } catch (e) {}

                // Tìm đáp án theo pattern "Đáp án đúng là: ..."
                let answer = null;
                
                // Tìm trong element hiện tại và các element xung quanh
                const searchContext = element.closest('.que, .question, .quiz-question, [class*="question-container"]') || element.parentElement;
                
                if (searchContext) {
                    const contextText = searchContext.innerText || '';
                    
                    // Pattern: "Đáp án đúng là: ABC" hoặc "Đáp án đúng là ABC"
                    const answerPatterns = [
                        /Đáp án đúng là:\s*(.+?)(?:\n|$)/i,
                        /Đáp án đúng là\s+(.+?)(?:\n|$)/i,
                        /Correct answer is:\s*(.+?)(?:\n|$)/i,
                        /Đáp án:\s*(.+?)(?:\n|$)/i,
                        /Answer:\s*(.+?)(?:\n|$)/i
                    ];

                    for (const pattern of answerPatterns) {
                        const match = contextText.match(pattern);
                        if (match && match[1]) {
                            answer = match[1].trim();
                            // Loại bỏ các ký tự không cần thiết
                            answer = answer.replace(/[.。,，;；]+$/, '').trim();
                            if (answer.length > 0 && answer.length < 500) {
                                break;
                            }
                        }
                    }
                }

                questions.push({
                    question: questionText,
                    answer: answer,
                    element: element,
                    index: index
                });

            } catch (error) {
                console.error('Error extracting question:', error);
            }
        });

        return questions;
    }

    // Load existing questions from extension storage
    async function loadExistingQuestions() {
        try {
            const result = await chrome.storage.local.get(['tailieu_questions']);
            existingQuestions = result.tailieu_questions || [];
            // Build normalized key set for fast lookup
            existingQuestionKeys = new Set((existingQuestions || []).map(q => normalizedQuestionKey(q.question || q)));
            console.log(`[scanner] Loaded ${existingQuestions.length} existing questions from storage`);
            // DEBUG: show a few sample keys
            try {
                const sample = Array.from(existingQuestionKeys).slice(0, 8);
                console.debug('[scanner] existingQuestionKeys sample:', sample);
            } catch (e) {}
        } catch (error) {
            console.error('Error loading existing questions:', error);
            existingQuestions = [];
        }
    }

    // Check if question already exists in database
    function isQuestionNew(questionText) {
        const key = normalizedQuestionKey(questionText);
        return !existingQuestionKeys.has(key);
    }

    // Build a normalized key for a question for robust matching
    function normalizedQuestionKey(text) {
        if (!text) return '';
        try {
            const cleaned = cleanQuestionText(text);
            const core = extractCoreQuestion(cleaned);
            return normalizeText(core);
        } catch (e) {
            return normalizeText(text || '');
        }
    }

    // Merge duplicate questions (only merge if both question AND answer are the same)
    function mergeDuplicateQuestions(questions) {
        if (questions.length === 0) return [];
        
        const merged = [];
        const processed = new Set();
        
        for (let i = 0; i < questions.length; i++) {
            if (processed.has(i)) continue;
            
            const currentQ = questions[i];
            const duplicates = [currentQ];
            
            // Find all duplicates of current question (must have same question AND same answer)
            for (let j = i + 1; j < questions.length; j++) {
                if (processed.has(j)) continue;
                
                const otherQ = questions[j];
                
                // Only merge if both question and answer are the same
                if (isDuplicateQuestion(currentQ.question, otherQ.question)) {
                    // Check if answers are also the same (or both null)
                    const currentAnswer = (currentQ.answer || '').trim().toLowerCase();
                    const otherAnswer = (otherQ.answer || '').trim().toLowerCase();
                    
                    if (currentAnswer === otherAnswer) {
                        duplicates.push(otherQ);
                        processed.add(j);
                    }
                }
            }
            
            // Merge duplicates only if we found actual duplicates
            if (duplicates.length > 1) {
                // Keep the first question
                const mergedItem = {
                    question: currentQ.question,
                    answer: currentQ.answer || null,
                    duplicateCount: duplicates.length
                };
                
                merged.push(mergedItem);
            } else {
                merged.push(currentQ);
            }
            
            processed.add(i);
        }
        
        return merged;
    }

    // Scan and show new questions
    async function scanQuestions() {
    console.log('Starting question scan...');
        
        // Show loading notification
        showNotification('Đang quét câu hỏi...', 'info', 2000);

        // Load existing questions first
        await loadExistingQuestions();

        // Extract questions from page
        const allQuestions = extractQuestionsFromPage();
        console.log(`Found ${allQuestions.length} questions on page`);

        // Clean extracted questions first
        let cleanedQuestions = allQuestions
            .map(q => ({
                ...q,
                question: cleanQuestionText(q.question)
            }))
            // Remove invalid/empty cleaned questions
            .filter(q => q.question && q.question.length > 0);

        // Merge duplicate questions
        scannedQuestions = mergeDuplicateQuestions(cleanedQuestions);

        // Initialize selection state for UI (selected by default)
        scannedQuestions.forEach(q => { try { q.selected = true; } catch (e) {} });

        // After merging, remove noisy phrases
        scannedQuestions = scannedQuestions.filter(q => {
            try {
                const txt = (q.question || '').toString().toLowerCase();
                if (/đáp án/.test(txt)) return false;
                if (/(trang này|trang nay)/i.test(txt)) return false;
                return true;
            } catch (e) {
                return true;
            }
        });

        // Include question if it's not in DB OR if it exists in DB but has no answer yet
        function shouldIncludeQuestion(q) {
            try {
                    const key = normalizedQuestionKey(q.question);
                    const existing = (existingQuestions || []).find(e => normalizedQuestionKey(e.question || e) === key);
                    // DEBUG: show key and whether match found
                    console.debug('[scanner] shouldIncludeQuestion key=', key, 'foundExisting=', !!existing);
                    if (!existing) return true; // not in DB -> include
                    const existingAnswer = (existing && existing.answer) ? String(existing.answer).trim() : '';
                    console.debug('[scanner] existingAnswer length=', existingAnswer.length ? existingAnswer.length : 0);
                    return existingAnswer.length === 0; // include only if DB answer is empty
            } catch (e) {
                return true;
            }
        }

        scannedQuestions = scannedQuestions.filter(shouldIncludeQuestion);

        console.log(`Found ${scannedQuestions.length} questions (new or missing answer in DB, after merging duplicates)`);

        if (scannedQuestions.length === 0) {
            showNotification('Không tìm thấy câu hỏi mới', 'info', 3000);
            return;
        }

        // Show popup with scanned questions
        showScannerPopup();
        
        showNotification(`Đã quét được ${scannedQuestions.length} câu hỏi mới`, 'success', 3000);
    }

    // Show notification
    function showNotification(message, type = 'info', duration = 5000) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 16px 24px;
            background: ${type === 'success' ? '#4CAF50' : type === 'error' ? '#f44336' : '#2196F3'};
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            z-index: 10002;
            font-size: 14px;
            font-weight: 500;
            max-width: 300px;
            animation: slideInRight 0.3s ease-out;
        `;
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => notification.remove(), 300);
        }, duration);
    }

    // Show scanner popup with results
    function showScannerPopup() {
        // Remove existing popup if any
        const existingPopup = document.getElementById('tailieu-scanner-popup');
        if (existingPopup) {
            existingPopup.remove();
        }

        const popup = document.createElement('div');
        popup.id = 'tailieu-scanner-popup';
        popup.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 20px;
            width: 500px;
            max-height: 600px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            z-index: 10003;
            display: flex;
            flex-direction: column;
            font-family: Arial, sans-serif;
            animation: slideInLeft 0.3s ease-out;
        `;

        // Header
        const header = document.createElement('div');
        // Blue/white theme to match main questions popup
        header.style.cssText = `
            padding: 16px 20px;
            background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%);
            color: white;
            border-radius: 12px 12px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        `;
        
        const title = document.createElement('div');
    const titleMain = document.createElement('div');
    titleMain.style.cssText = 'font-size: 18px; font-weight: bold; display:flex; align-items:center; gap:8px;';
    const titleIcon = svgIcon('search', 18);
    titleMain.appendChild(titleIcon);
    const titleTextNode = document.createElement('span');
    titleTextNode.textContent = 'Câu hỏi mới';
    titleMain.appendChild(titleTextNode);

        const titleSub = document.createElement('div');
        titleSub.style.cssText = 'font-size: 12px; opacity: 0.9; margin-top: 4px;';
        titleSub.textContent = `${scannedQuestions.length} câu hỏi chưa có trong database`;

        title.appendChild(titleMain);
        title.appendChild(titleSub);
        
        const closeBtn = document.createElement('button');
    closeBtn.innerHTML = '';
    closeBtn.appendChild(svgIcon('close', 14));
        closeBtn.style.cssText = `
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s;
        `;
        closeBtn.onmouseover = () => closeBtn.style.background = 'rgba(255,255,255,0.3)';
        closeBtn.onmouseout = () => closeBtn.style.background = 'rgba(255,255,255,0.2)';
        closeBtn.onclick = () => popup.remove();

        header.appendChild(title);
        header.appendChild(closeBtn);

        // Question list container
        const listContainer = document.createElement('div');
        listContainer.style.cssText = `
            flex: 1;
            overflow-y: auto;
            padding: 16px;
            background: #f5f5f5;
        `;

        // Selection controls (select all)
        const selectionBar = document.createElement('div');
        selectionBar.style.cssText = 'display:flex; align-items:center; gap:12px; padding: 12px 16px;';

        const selectAllWrapper = document.createElement('label');
        selectAllWrapper.style.cssText = 'display:flex; align-items:center; gap:8px; font-size:13px; color:#333; cursor:pointer;';
        const selectAllCheckbox = document.createElement('input');
        selectAllCheckbox.type = 'checkbox';
        selectAllCheckbox.id = 'tailieu-scanner-select-all';
        selectAllCheckbox.checked = scannedQuestions.length > 0 && scannedQuestions.every(i => i.selected);
        const selectAllText = document.createElement('span');
        selectAllText.textContent = 'Chọn tất cả';
        selectAllWrapper.appendChild(selectAllCheckbox);
        selectAllWrapper.appendChild(selectAllText);
        selectionBar.appendChild(selectAllWrapper);

        // Add a small counter of selected items
        const selectedCounter = document.createElement('div');
        selectedCounter.id = 'tailieu-scanner-selected-count';
        selectedCounter.style.cssText = 'font-size:13px; color:#666; margin-left:auto;';
        const updateSelectedCounter = () => {
            const c = scannedQuestions.filter(i => i.selected).length;
            selectedCounter.textContent = `${c} đã chọn`;
        };
        updateSelectedCounter();
        selectionBar.appendChild(selectedCounter);

        // Toggle all
        selectAllCheckbox.addEventListener('change', () => {
            const val = selectAllCheckbox.checked;
            scannedQuestions.forEach(i => { i.selected = val; });
            // Update item checkboxes in list
            const itemCheckboxes = listContainer.querySelectorAll('.tailieu-scanner-item-checkbox');
            itemCheckboxes.forEach(cb => { cb.checked = val; });
            updateSelectedCounter();
        });

        // Insert selection bar above list
        listContainer.appendChild(selectionBar);

        // Add questions to list
        scannedQuestions.forEach((item, index) => {
            const questionItem = document.createElement('div');
            questionItem.style.cssText = `
                background: white;
                border-radius: 8px;
                padding: 16px;
                margin-bottom: 12px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                transition: transform 0.2s, box-shadow 0.2s;
            `;
            questionItem.onmouseover = () => {
                questionItem.style.transform = 'translateY(-2px)';
                questionItem.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
            };
            questionItem.onmouseout = () => {
                questionItem.style.transform = 'translateY(0)';
                questionItem.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
            };

            const questionNumber = document.createElement('div');
            questionNumber.style.cssText = `
                font-size: 12px;
                color: #667eea;
                font-weight: bold;
                margin-bottom: 8px;
                display: flex;
                align-items: center;
                gap: 8px;
            `;
            // Checkbox for selecting this scanned item
            const itemCheckbox = document.createElement('input');
            itemCheckbox.type = 'checkbox';
            itemCheckbox.className = 'tailieu-scanner-item-checkbox';
            itemCheckbox.style.cssText = 'width:16px; height:16px; cursor:pointer;';
            itemCheckbox.checked = !!item.selected;
            itemCheckbox.addEventListener('change', () => {
                item.selected = itemCheckbox.checked;
                // Update selectAll state
                const allSelected = scannedQuestions.length > 0 && scannedQuestions.every(i => i.selected);
                const anySelected = scannedQuestions.some(i => i.selected);
                const selectAllEl = document.getElementById('tailieu-scanner-select-all');
                if (selectAllEl) selectAllEl.checked = allSelected;
                updateSelectedCounter();
                // Disable export/copy if none selected (visual cue)
            });
            questionNumber.appendChild(itemCheckbox);
                const numberText = document.createElement('span');
                numberText.textContent = `Câu ${index + 1}`;
            questionNumber.appendChild(numberText);
            // Delete button for removing scanned item
            const deleteBtn = document.createElement('button');
            // show a small close icon + text
            deleteBtn.innerHTML = '';
            const delIcon = svgIcon('close', 12);
            deleteBtn.appendChild(delIcon);
            const delText = document.createElement('span');
            delText.textContent = ' Xóa';
            deleteBtn.appendChild(delText);
            deleteBtn.title = 'Xóa câu hỏi khỏi danh sách quét';
            deleteBtn.style.cssText = `
                margin-left: 8px;
                background: #f44336;
                color: white;
                border: none;
                padding: 4px 8px;
                border-radius: 6px;
                cursor: pointer;
                font-size: 12px;
            `;
            deleteBtn.onmouseover = () => deleteBtn.style.opacity = '0.9';
            deleteBtn.onmouseout = () => deleteBtn.style.opacity = '1';
            deleteBtn.onclick = () => {
                try {
                    if (!confirm('Xóa câu hỏi này khỏi danh sách quét?')) return;
                    const idx = scannedQuestions.indexOf(item);
                    if (idx !== -1) {
                        scannedQuestions.splice(idx, 1);
                    }
                    questionItem.remove();
                    // Update numbering and header count
                    updateListNumbers();
                    titleSub.textContent = `${scannedQuestions.length} câu hỏi chưa có trong database`;
                    // Update selected counter and select-all state
                    updateSelectedCounter();
                    const selectAllEl = document.getElementById('tailieu-scanner-select-all');
                    if (selectAllEl) selectAllEl.checked = scannedQuestions.length > 0 && scannedQuestions.every(i => i.selected);
                    // If no more items, remove popup
                    if (scannedQuestions.length === 0) {
                        popup.remove();
                        showNotification('Không còn câu hỏi trong danh sách quét', 'info', 2500);
                    }
                } catch (e) {
                    console.error('Error deleting scanned item', e);
                }
            };
            questionNumber.appendChild(deleteBtn);
            
            // Add merge badge if this question was merged from duplicates
            if (item.duplicateCount && item.duplicateCount > 1) {
                const mergeBadge = document.createElement('span');
                mergeBadge.style.cssText = `
                    background: #FF9800;
                    color: white;
                    padding: 2px 8px;
                    border-radius: 12px;
                    font-size: 11px;
                    font-weight: bold;
                `;
                // prepend merge svg
                const mergeIcon = svgIcon('merge', 12);
                mergeIcon.style.marginRight = '6px';
                mergeBadge.appendChild(mergeIcon);
                const mergeText = document.createElement('span');
                mergeText.textContent = `Hợp nhất ${item.duplicateCount} câu`;
                mergeBadge.appendChild(mergeText);
                questionNumber.appendChild(mergeBadge);
            }

            const questionText = document.createElement('div');
            questionText.style.cssText = `
                font-size: 14px;
                color: #333;
                line-height: 1.6;
                margin-bottom: 8px;
                font-weight: 500;
            `;
            questionText.textContent = item.question;

            questionItem.appendChild(questionNumber);
            questionItem.appendChild(questionText);

            // Add answer if found
            if (item.answer) {
                const answerLabel = document.createElement('div');
                answerLabel.style.cssText = `
                    font-size: 12px;
                    color: #4CAF50;
                    font-weight: bold;
                    margin-top: 12px;
                    margin-bottom: 4px;
                `;
                // prepend check svg
                const answerIcon = svgIcon('check', 14);
                answerLabel.textContent = '';
                answerLabel.appendChild(answerIcon);
                const answerLabelText = document.createElement('span');
                answerLabelText.style.marginLeft = '8px';
                answerLabelText.textContent = 'Đáp án:';
                answerLabel.appendChild(answerLabelText);

                const answerText = document.createElement('div');
                answerText.style.cssText = `
                    font-size: 13px;
                    color: #2E7D32;
                    padding: 8px 12px;
                    background: #E8F5E9;
                    border-radius: 6px;
                    border-left: 3px solid #4CAF50;
                `;
                answerText.textContent = item.answer;

                questionItem.appendChild(answerLabel);
                questionItem.appendChild(answerText);
            } else {
                const noAnswer = document.createElement('div');
                noAnswer.style.cssText = `
                    font-size: 12px;
                    color: #FF9800;
                    font-style: italic;
                    margin-top: 8px;
                    padding: 6px 10px;
                    background: #FFF3E0;
                    border-radius: 6px;
                    border-left: 3px solid #FF9800;
                `;
                // use plain text warning (no emoji)
                noAnswer.textContent = 'Chưa quét được đáp án';
                questionItem.appendChild(noAnswer);
            }

            listContainer.appendChild(questionItem);
        });

        // Helper to re-number visible items after deletion
        function updateListNumbers() {
            const items = listContainer.querySelectorAll('div');
            // Find question-number spans and update their textContent
            const numberSpans = listContainer.querySelectorAll('div > div:first-child > span');
            numberSpans.forEach((span, i) => {
                span.textContent = `Câu ${i + 1}`;
            });
        }

    // Footer with actions
        const footer = document.createElement('div');
        footer.style.cssText = `
            padding: 16px 20px;
            background: white;
            border-top: 1px solid #e0e0e0;
            border-radius: 0 0 12px 12px;
            display: flex;
            gap: 12px;
            justify-content: flex-end;
        `;

            const exportBtn = document.createElement('button');
            exportBtn.textContent = '';
            exportBtn.appendChild(svgIcon('save', 16));
            const exportText = document.createElement('span');
            exportText.style.marginLeft = '8px';
            exportText.textContent = 'Lưu vào DB';
            exportBtn.appendChild(exportText);
            exportBtn.title = 'Lưu các câu hỏi đã quét vào cơ sở dữ liệu (mở popup để đồng bộ)';
            exportBtn.style.cssText = `
                padding: 10px 20px;
                background: #1976D2;
                color: white;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-size: 14px;
                font-weight: 500;
                transition: background 0.2s;
            `;
            exportBtn.onmouseover = () => exportBtn.style.background = '#1976D2';
            exportBtn.onmouseout = () => exportBtn.style.background = '#2196F3';
            exportBtn.onclick = () => saveScannedToLocalAndNotify();

        // (Direct add-now button removed)
            
            // Manual add button - open a small modal to input question and answer
            const manualAddBtn = document.createElement('button');
            manualAddBtn.textContent = '';
            manualAddBtn.appendChild(svgIcon('edit', 16));
            const manualAddText = document.createElement('span');
            manualAddText.style.marginLeft = '8px';
            manualAddText.textContent = 'Thêm thủ công';
            manualAddBtn.appendChild(manualAddText);
            manualAddBtn.title = 'Thêm câu hỏi/đáp án mà scanner không quét được';
            manualAddBtn.style.cssText = `
                padding: 10px 16px;
                background: #FFB300;
                color: #222;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-size: 14px;
                font-weight: 500;
            `;
            manualAddBtn.onmouseover = () => manualAddBtn.style.opacity = '0.9';
            manualAddBtn.onmouseout = () => manualAddBtn.style.opacity = '1';
            manualAddBtn.onclick = () => showManualAddDialog();

    const copyBtn = document.createElement('button');
    copyBtn.textContent = '';
    copyBtn.appendChild(svgIcon('copy', 14));
    const copyText = document.createElement('span');
    copyText.style.marginLeft = '8px';
    copyText.textContent = 'Copy';
    copyBtn.appendChild(copyText);
        copyBtn.style.cssText = `
            padding: 10px 20px;
            background: #4CAF50; /* keep copy green for clarity */
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: background 0.2s;
        `;
        copyBtn.onmouseover = () => copyBtn.style.background = '#45a049';
        copyBtn.onmouseout = () => copyBtn.style.background = '#4CAF50';
    copyBtn.onclick = () => copyToClipboard();

        // Save scanned questions into chrome.storage.local for the popup to pick up and sync to Firestore
        function saveScannedToLocalAndNotify() {
            try {
                const selectedItems = scannedQuestions.filter(i => i.selected);
                const toSave = selectedItems.length > 0 ? selectedItems : scannedQuestions;

                const payload = toSave.map((item) => ({
                    question: item.question || null,
                    answer: item.answer || null,
                    duplicateCount: item.duplicateCount || 0
                }));

                // Save to local storage under a specific key
                chrome.storage.local.set({ tailieu_scanner_pending: payload }, () => {
                    if (chrome.runtime.lastError) {
                        console.error('Error saving scanned questions to storage:', chrome.runtime.lastError);
                        showNotification('Lỗi lưu tạm: ' + (chrome.runtime.lastError.message || ''), 'error', 4000);
                        return;
                    }

                    // Send a message so other parts (popup) can react immediately if open
                    try {
                        chrome.runtime.sendMessage({ action: 'tailieu_scanner_saved_local', count: payload.length });
                    } catch (e) {
                        // ignore - runtime may not be available in some contexts
                    }

                    showNotification('Đã lưu tạm vào bộ nhớ tiện ích. Mở popup để đồng bộ vào DB.', 'success', 3500);
                });
            } catch (e) {
                console.error('saveScannedToLocalAndNotify error', e);
                showNotification('Lỗi khi lưu câu hỏi', 'error', 3000);
            }
        }

        // Show a small modal to add a question manually
        function showManualAddDialog() {
            // Create overlay
            const overlay = document.createElement('div');
            overlay.className = 'tailieu-overlay';

            const modal = document.createElement('div');
            modal.className = 'tailieu-modal';
            // Make the manual-add modal larger and responsive
            modal.style.cssText = `
                width: 720px;
                max-width: calc(100vw - 40px);
                max-height: 80vh;
                overflow: auto;
                padding: 18px;
            `;
            modal.innerHTML = `
                <h3 style="margin-top:0; font-size:18px;">Thêm câu hỏi thủ công</h3>
                <div style="display:flex; flex-direction:column; gap:10px;">
                    <label style="font-size:14px; color:#333;">Câu hỏi</label>
                    <textarea id="tailieu-manual-question" rows="6" style="width:100%; height:180px; padding:10px; font-size:14px; resize:vertical;"></textarea>
                    <label style="font-size:14px; color:#333;">Đáp án (tùy chọn)</label>
                    <textarea id="tailieu-manual-answer" rows="6" style="width:100%; height:180px; padding:10px; font-size:14px; resize:vertical;"></textarea>
                    <div style="display:flex; gap:8px; justify-content:flex-end; margin-top:6px;">
                        <button id="tailieu-manual-cancel" style="background:#eee; border:none; padding:10px 14px; border-radius:6px; cursor:pointer;">Hủy</button>
                        <button id="tailieu-manual-add" style="background:#1976D2; color:white; border:none; padding:10px 14px; border-radius:6px; cursor:pointer;">Thêm</button>
                    </div>
                </div>
            `;

            overlay.appendChild(modal);
            document.body.appendChild(overlay);

            const cancelBtn = document.getElementById('tailieu-manual-cancel');
            const addBtn = document.getElementById('tailieu-manual-add');

            cancelBtn.onclick = () => overlay.remove();

            addBtn.onclick = () => {
                const qEl = document.getElementById('tailieu-manual-question');
                const aEl = document.getElementById('tailieu-manual-answer');
                const qText = qEl.value && qEl.value.trim();
                const aText = aEl.value && aEl.value.trim();

                if (!qText || qText.length < 5) {
                    alert('Vui lòng nhập câu hỏi hợp lệ (ít nhất 5 ký tự)');
                    return;
                }

                const newItem = {
                    question: qText,
                    answer: aText || null,
                    duplicateCount: 1,
                    selected: true
                };

                // Add to scannedQuestions and refresh popup
                scannedQuestions.unshift(newItem);
                overlay.remove();
                // Re-render popup: remove and recreate
                const existingPopup = document.getElementById('tailieu-scanner-popup');
                if (existingPopup) existingPopup.remove();
                showScannerPopup();
            };
        }

    // Append action buttons: Manual Add, Save (local), Copy
    footer.appendChild(manualAddBtn);
    footer.appendChild(exportBtn);
    footer.appendChild(copyBtn);

        // Assemble popup
        popup.appendChild(header);
        popup.appendChild(listContainer);
        popup.appendChild(footer);

        document.body.appendChild(popup);

        // Add slide in animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInLeft {
                from {
                    transform: translateX(-100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
        `;
        if (!document.getElementById('tailieu-scanner-styles')) {
            style.id = 'tailieu-scanner-styles';
            document.head.appendChild(style);
        }
    }

    // Export to JSON file
    // Export to JSON file
    function exportToJSON() {
        const selectedItems = scannedQuestions.filter(i => i.selected);
        const toExport = selectedItems.length > 0 ? selectedItems : scannedQuestions;

        const data = toExport.map((item, index) => {
            const exported = {
                id: index + 1,
                question: item.question,
                answer: item.answer || null
            };
            
            // Add merge info if this question was merged
            if (item.duplicateCount && item.duplicateCount > 1) {
                exported.duplicateCount = item.duplicateCount;
                exported.mergedFrom = `${item.duplicateCount} câu hỏi giống nhau`;
            }
            
            // Add other answers if available
            if (item.answers && item.answers.length > 1) {
                exported.alternativeAnswers = item.answers.slice(1);
            }
            
            return exported;
        });

        const jsonStr = JSON.stringify(data, null, 2);
        const blob = new Blob([jsonStr], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `tailieu-questions-${new Date().getTime()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        showNotification('Đã xuất file JSON', 'success', 3000);
    }

    // Copy to clipboard
    function copyToClipboard() {
        const selectedItems = scannedQuestions.filter(i => i.selected);
        const toCopy = selectedItems.length > 0 ? selectedItems : scannedQuestions;

    let text = `CÂU HỎI MỚI (${toCopy.length})\n\n`;

        toCopy.forEach((item, index) => {
            text += `${index + 1}. ${item.question}\n`;
            
            // Add merge info if available
            if (item.duplicateCount && item.duplicateCount > 1) {
                text += `   Hợp nhất ${item.duplicateCount} câu hỏi giống nhau\n`;
            }

            if (item.answer) {
                text += `   Đáp án: ${item.answer}\n`;
            } else {
                text += `   (Chưa có đáp án)\n`;
            }

            // Add alternative answers if available
            if (item.answers && item.answers.length > 1) {
                text += `   Các đáp án khác: ${item.answers.slice(1).join(', ')}\n`;
            }
            
            text += '\n';
        });

        navigator.clipboard.writeText(text).then(() => {
            showNotification('Đã copy vào clipboard', 'success', 3000);
        }).catch(err => {
            console.error('Failed to copy:', err);
            showNotification('Lỗi copy clipboard', 'error', 3000);
        });
    }

    // Create floating scanner button
    function createScannerButton() {
        const button = document.createElement('button');
        button.id = 'tailieu-scanner-btn';
        button.title = 'Quét câu hỏi mới';
        // use svg search icon inside floating button
        button.appendChild(svgIcon('search', 20));
        button.style.cssText = `
            position: fixed !important;
            bottom: 80px !important;
            right: 20px !important;
            width: 56px !important;
            height: 56px !important;
            border-radius: 50% !important;
            background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%) !important;
            color: white !important;
            border: none !important;
            font-size: 24px !important;
            cursor: pointer !important;
            box-shadow: 0 4px 12px rgba(25, 118, 210, 0.35) !important;
            transition: all 0.3s !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            z-index: 10001 !important;
        `;

        button.onmouseover = () => {
            button.style.transform = 'scale(1.1)';
            button.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.6)';
        };

        button.onmouseout = () => {
            button.style.transform = 'scale(1)';
            button.style.boxShadow = '0 4px 12px rgba(102, 126, 234, 0.4)';
        };

        // When clicking scan: first minimize external questions popup (if any), then start scan
        button.onclick = () => {
            try {
                minimizeQuestionsPopup();
            } catch (e) {
                console.error('Error minimizing questions popup', e);
            }
            scanQuestions();
        };

        document.body.appendChild(button);

        // Ensure default position is bottom-right (use inline !important to override stylesheet if needed)
        try {
            button.style.removeProperty('left');
            button.style.removeProperty('top');
            button.style.setProperty('bottom', '80px', 'important');
            button.style.setProperty('right', '20px', 'important');
        } catch (e) {}

        // Position scanner above popup if popup exists; otherwise keep default
        function positionScannerRelativeToPopup() {
            try {
                const popup = document.getElementById('tailieu-questions-popup');
                const btnW = button.offsetWidth || 56;
                const btnH = button.offsetHeight || 56;
                if (popup && popup.style.display !== 'none') {
                    const rect = popup.getBoundingClientRect();
                    // align to the popup's top-right edge (sát mép phải)
                    const margin = 8; // small gap from popup edge
                    let left = Math.round(rect.left + rect.width - btnW - margin);
                    let top = Math.round(rect.top - btnH - 12);
                    if (left < 8) left = 8;
                    if (top < 8) top = 8;
                    // remove bottom/right so left/top take effect
                    button.style.removeProperty('right');
                    button.style.removeProperty('bottom');
                    button.style.setProperty('left', left + 'px', 'important');
                    button.style.setProperty('top', top + 'px', 'important');
                } else {
                    // If there's a floating 'open popup' button, position scanner near it
                    const floating = document.getElementById('tailieu-floating-btn');
                    if (floating) {
                        try {
                            const fRect = floating.getBoundingClientRect();
                            const distanceToBottom = window.innerHeight - (fRect.top + fRect.height);
                            // Only align to floating if floating is near bottom area (so scanner won't jump to top-left)
                            if (distanceToBottom >= 0 && distanceToBottom < 200) {
                                // place scanner above floating button (align to its right edge)
                                let left = Math.round(fRect.left + fRect.width - btnW);
                                let top = Math.round(fRect.top - btnH - 8);
                                // clamp to viewport
                                const minLeft = 8;
                                const maxLeft = Math.max(8, window.innerWidth - btnW - 8);
                                if (left < minLeft) left = minLeft;
                                if (left > maxLeft) left = maxLeft;
                                if (isNaN(top) || top < 8) top = Math.max(8, Math.round(fRect.top - btnH - 8));
                                // remove bottom/right and set left/top important
                                button.style.removeProperty('right');
                                button.style.removeProperty('bottom');
                                button.style.setProperty('left', left + 'px', 'important');
                                button.style.setProperty('top', top + 'px', 'important');
                            } else {
                                // default to bottom-right if floating is not near bottom
                                button.style.removeProperty('left');
                                button.style.removeProperty('top');
                                button.style.setProperty('bottom', '80px', 'important');
                                button.style.setProperty('right', '20px', 'important');
                            }
                        } catch (e) {
                            // fallback to default bottom-right
                            button.style.removeProperty('left');
                            button.style.removeProperty('top');
                            button.style.setProperty('bottom', '80px', 'important');
                            button.style.setProperty('right', '20px', 'important');
                        }
                    } else {
                        // fallback to default bottom-right
                        button.style.removeProperty('left');
                        button.style.removeProperty('top');
                        button.style.setProperty('bottom', '80px', 'important');
                        button.style.setProperty('right', '20px', 'important');
                    }
                }
            } catch (e) {
                // ignore positioning errors
            }
        }

    // Run initial positioning and keep it updated
    positionScannerRelativeToPopup();
    // run again shortly after to override any stylesheet race conditions
    setTimeout(positionScannerRelativeToPopup, 120);
        window.addEventListener('resize', positionScannerRelativeToPopup);
        window.addEventListener('scroll', positionScannerRelativeToPopup, true);

        // Observe DOM changes to reposition when popup is created/removed or its style changes
        const mo = new MutationObserver(() => {
            positionScannerRelativeToPopup();
        });
        mo.observe(document.body, { childList: true, subtree: true, attributes: true });
    }

    // Initialize scanner when page is ready
    function initScanner() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                setTimeout(createScannerButton, 1000);
            });
        } else {
            setTimeout(createScannerButton, 1000);
        }
    }

    // Start scanner
    initScanner();

    // Minimize an existing extension questions popup (#tailieu-questions-popup) into a small floating button
    function minimizeQuestionsPopup() {
        try {
            const existingPopup = document.getElementById('tailieu-questions-popup');
            if (!existingPopup) return;
            // Prefer using the popup's own minimize button if available (so it preserves data)
            try {
                const minimizeBtn = existingPopup.querySelector('button');
                // Heuristic: find the minimize button by looking for a button with '−' text
                let found = null;
                const buttons = existingPopup.querySelectorAll('button');
                buttons.forEach(btn => {
                    if (btn.textContent && btn.textContent.trim() === '−') {
                        found = btn;
                    }
                });
                if (found) {
                    // If already minimized via popup internal state, clicking will toggle
                    found.click();
                    return;
                }
            } catch (e) {
                // ignore and fallback
            }

            // Fallback: If popup does not expose minimize button, hide popup and create a small restore button
            if (document.getElementById('tailieu-questions-min-btn')) return;

            // Hide the popup
            existingPopup.style.display = 'none';

            // Create a small restore button (blue/white theme)
            const restoreBtn = document.createElement('button');
            restoreBtn.id = 'tailieu-questions-min-btn';
            restoreBtn.title = 'Mở lại danh sách câu hỏi';
            // use SVG book icon
            restoreBtn.appendChild(svgIcon('book', 16));
            restoreBtn.style.cssText = `
                position: fixed;
                top: 80px;
                left: 20px;
                width: 44px;
                height: 44px;
                border-radius: 8px;
                background: linear-gradient(135deg, #2196F3, #1976D2);
                color: white;
                border: none;
                font-size: 18px;
                z-index: 99999; /* lower than scanner button but above most page content */
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(25,118,210,0.25);
            `;

            restoreBtn.onclick = () => {
                const popup = document.getElementById('tailieu-questions-popup');
                if (popup) popup.style.display = '';
                restoreBtn.remove();
            };

            document.body.appendChild(restoreBtn);
        } catch (e) {
            console.error('minimizeQuestionsPopup error', e);
        }
    }

    // Listen for messages from popup/background
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'scanQuestions') {
            scanQuestions();
            sendResponse({ success: true });
        }
    });

})();
